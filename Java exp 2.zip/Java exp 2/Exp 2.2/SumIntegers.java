public class SumIntegers {
    public static void main(String[] args) {
        System.out.println("--- Sum of Integers Using Autoboxing and Unboxing ---");


        Integer num1 = 10;
        Integer num2 = 20;
        Integer num3 = 30;

       
        int sum = num1 + num2 + num3;

        System.out.println("Numbers: " + num1 + ", " + num2 + ", " + num3);
        System.out.println("Sum: " + sum);
    }
}
